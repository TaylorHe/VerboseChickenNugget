To compile and run:
	> javac SubstringDivisibility.java
	> java SubstringDivisibility <digits>

As an example parameter, running 
	> java SubstringDivisibility 0123456789
will return 16695334890, which is the correct answer on Project Euler #43

To run the test script:
	> bash StrDivTest.sh

